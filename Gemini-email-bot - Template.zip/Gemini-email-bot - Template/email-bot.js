const path = require('path');
require('dotenv').config({ path: "env_file_location" }); // add the location of your .env file here
const { google } = require('googleapis');
const { authenticate } = require('@google-cloud/local-auth');
const schedule = require('node-schedule');
const https = require('https');

async function getMyContext() {
    var context = "You are an AI assistant for ... , a personal trainer. " +
          "Your task is to analyze incoming emails and provide responses related to fitness, health advice, and Gabriel's services of meal plans and training plans. " +
          "For each email, please perform the following tasks:\n" +
          "1) If they are asking or have questions regarding a meal plan, check if they mentioned having filled in the meal plan survey on my website, if not ask them to do so and say that i will soon respond personally.\n" +
          "2) If they have questions regarding to a workout plan, just tell them who you are and that i will be replying soon.\n" +
          "3) If they are asking a general fitness question answer to the best of your ability, provide sources for your information, and let the sender know that I will be responding shortly.\n" +
          "4) Mention at the start that you are my ai assistant and that you are here to help assist with their questions.\n\n" +
          "Below, you will find the details of an email to analyze:"; // this is a mockup prompt, modify it to your use case
        
        return context;
}

async function retrieveEmails(auth) {
  const gmail = google.gmail({ version: 'v1', auth });
  const res = await gmail.users.messages.list({
    userId: 'me',
    q: 'is:unread to:your_email_here', // add your email address
    maxResults: 5
  });
  return res.data.messages || [];
}

async function callGemini(prompt) {
  return new Promise((resolve, reject) => {
    const geminiApiKey = process.env.GEMINI_API_KEY;
    if (!geminiApiKey) {
      reject(new Error("Gemini API key not found in environment variables"));
      return;
    }

    const safetySettings = [
      {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_LOW_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_LOW_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_LOW_AND_ABOVE"
      },
      {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_LOW_AND_ABOVE"
      }
    ];
    const generationConfig = {
      temperature: 1.0,
      topK: 0,
      topP: 1,
      maxOutputTokens: 2000,
    };

    const payload = JSON.stringify({
      "contents": [{
        "parts":[{
          "text": prompt
        }]
      }],
      safetySettings,
      generationConfig
    });

    const options = {
      hostname: 'generativelanguage.googleapis.com',
      path: `/v1/models/gemini-pro:generateContent?key=${geminiApiKey}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      }
    };

    const req = https.request(options, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        try {
          const responseData = JSON.parse(data);
          console.log("API Response: " + JSON.stringify(responseData)); // Logs the full response

          if (responseData.error) {
            reject(new Error(JSON.stringify(responseData.error)));
            return;
          }

          if (!responseData.candidates || responseData.candidates.length === 0) {
            reject(new Error("No candidates returned from the API"));
            return;
          }

          const candidate = responseData.candidates[0];
          if (!candidate.content || !candidate.content.parts || candidate.content.parts.length === 0) {
            reject(new Error("Unexpected response structure"));
            return;
          }

          const generatedText = candidate.content.parts[0].text;
          if (!generatedText) {
            reject(new Error("Generated text is empty"));
            return;
          }

          resolve(generatedText);
        } catch (error) {
          reject(new Error("Error parsing API response: " + error.message));
        }
      });
    });

    req.on('error', (error) => {
      reject(new Error("Error calling Gemini API: " + error.message));
    });

    req.write(payload);
    req.end();
  });
}

async function analyseEmails(auth) {
  const gmail = google.gmail({ version: 'v1', auth });
  const threads = await retrieveEmails(auth);
  const promptContext = await getMyContext();

  for (const thread of threads) {
    const res = await gmail.users.threads.get({ userId: 'me', id: thread.id });
    const message = res.data.messages[res.data.messages.length - 1];

    const subject = message.payload.headers.find(h => h.name === 'Subject').value;
    const sender = message.payload.headers.find(h => h.name === 'From').value;
    const emailBody = Buffer.from(message.payload.parts[0].body.data, 'base64').toString();

    const fullPrompt = `${promptContext}\n\nEmail Details:\nFrom: ${sender}\nSubject: ${subject}\n\nEmail Body:\n${emailBody}`;

    const response = await callGemini(fullPrompt);

    await gmail.users.messages.send({
      userId: 'me',
      requestBody: {
        raw: Buffer.from(
          `To: ${sender}\r\n` +
          `Subject: Re: ${subject}\r\n` +
          `Content-Type: text/plain; charset="UTF-8"\r\n` +
          `Content-Transfer-Encoding: 7bit\r\n\r\n` +
          `${response}`
        ).toString('base64')
      }
    });

    await gmail.users.threads.modify({
      userId: 'me',
      id: thread.id,
      requestBody: { removeLabelIds: ['UNREAD'] }
    });

    await new Promise(resolve => setTimeout(resolve, 1000));
  }
}

async function main() {
  const auth = await authenticate({
    keyfilePath: path.join(__dirname, 'oauth2.keys.json'),
    scopes: [
      'https://www.googleapis.com/auth/gmail.modify',
      'https://www.googleapis.com/auth/gmail.send',
      'https://www.googleapis.com/auth/userinfo.email',
      'https://www.googleapis.com/auth/gmail.readonly',
      'https://www.googleapis.com/auth/script.external_request'
    ],
  }); // make sure to add any extra scopes needed or remove unneeded ones

  schedule.scheduleJob('*/5 * * * *', async function() {
    await analyseEmails(auth);
  });
}

main().catch(console.error);